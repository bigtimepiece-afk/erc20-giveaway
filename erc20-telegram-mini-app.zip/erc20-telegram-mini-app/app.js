(() => {
  const tg = window.Telegram && window.Telegram.WebApp;
  if (tg) {
    tg.ready();
    tg.expand();
    try { tg.setHeaderColor("#06133d"); tg.setBackgroundColor("#050d2b"); } catch (_) {}
    const user = tg.initDataUnsafe && tg.initDataUnsafe.user;
    if (user && user.first_name) {
      document.querySelector(".brand-subtitle").textContent = `Welcome, ${user.first_name}`;
    }
  }

  document.getElementById("joinButton").addEventListener("click", () => {
    const message = "This is a demo. The organizer must publish verified prize details and connect a secure backend before entries can be accepted.";
    if (tg && tg.showPopup) {
      tg.showPopup({
        title: "Giveaway demo",
        message,
        buttons: [{ type: "ok" }]
      });
    } else {
      window.alert(message);
    }
  });
})();