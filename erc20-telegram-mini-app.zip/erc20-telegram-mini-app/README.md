# ERC20 Giveaway — Telegram Mini App demo

This is a static, mobile-first Telegram Mini App starter.

## Included
- `index.html` — landing page
- `styles.css` — responsive visual design
- `app.js` — Telegram Web Apps SDK initialization and demo button
- `assets/erc20-banner.png` — 640×360 banner
- `assets/erc20-demo.gif` — supplied demo animation

## Important: demo only
The Join Giveaway button currently displays a demo notice. It does **not** register entries or distribute tokens. Before accepting entries, add:
1. A backend endpoint that validates Telegram `initData` server-side using Telegram's documented HMAC verification.
2. A database and abuse/rate-limit controls for entries.
3. Real prize amount, token/network, eligibility, start/end times, winner-selection method and official terms.
4. A bot link and organizer contact details.
Never request seed phrases, private keys, wallet passwords, deposits or transaction approvals as a condition of entering.

## Publish to get your Web App URL
1. Upload this folder to a GitHub repository.
2. In Vercel or Netlify, import the repository and deploy it as a static site (no build command; publish/root directory is the project root).
3. Copy the HTTPS deployment URL, for example `https://your-project.vercel.app`.
4. In BotFather, configure the Mini App URL for your bot using that exact HTTPS URL.
5. Open the bot and test the Mini App on Telegram mobile and desktop.

The deployment URL is created by your hosting provider; this project does not itself create a public URL.
