require("dotenv").config();
const { pool } = require("../src/db");
const config = require("../src/config");

async function main() {
  if (!config.retentionEndAt) {
    throw new Error("Set RETENTION_END_AT before running cleanup.");
  }
  const end = new Date(config.retentionEndAt);
  if (Number.isNaN(end.getTime())) {
    throw new Error("RETENTION_END_AT must be a valid ISO 8601 timestamp.");
  }
  if (Date.now() < end.getTime()) {
    throw new Error("Retention period has not ended; no records were deleted.");
  }
  const result = await pool.query("DELETE FROM giveaway_entries");
  console.log(`Deleted ${result.rowCount} giveaway entries after the retention deadline.`);
}

main()
  .catch((error) => {
    console.error(error.message);
    process.exitCode = 1;
  })
  .finally(() => pool.end());
