require("dotenv").config();
const config = require("../src/config");

async function main() {
  if (!process.env.PUBLIC_API_URL) throw new Error("Set PUBLIC_API_URL before registering the webhook.");
  const url = `${process.env.PUBLIC_API_URL.replace(/\/$/, "")}/telegram/webhook`;
  const response = await fetch(
    `https://api.telegram.org/bot${config.botToken}/setWebhook`,
    {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        url,
        secret_token: config.webhookSecret,
        allowed_updates: ["message"],
        drop_pending_updates: false
      })
    }
  );
  const result = await response.json();
  if (!response.ok || !result.ok) {
    throw new Error(result.description || "Could not register webhook.");
  }

  const menuResponse = await fetch(
    `https://api.telegram.org/bot${config.botToken}/setChatMenuButton`,
    {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        menu_button: {
          type: "web_app",
          text: "Open Giveaway",
          web_app: { url: config.webappUrl }
        }
      })
    }
  );
  const menuResult = await menuResponse.json();
  if (!menuResponse.ok || !menuResult.ok) {
    throw new Error(menuResult.description || "Webhook set, but menu button setup failed.");
  }
  console.log("Webhook and Telegram menu button configured.");
}

main().catch((error) => {
  console.error(error.message);
  process.exit(1);
});
