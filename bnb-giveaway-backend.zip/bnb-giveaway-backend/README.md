# Telegram Giveaway Backend

A deployable starter backend for a Telegram Mini App giveaway. It records one entry per verified Telegram account, stores entries in PostgreSQL, encrypts optional email addresses, and provides a Telegram bot webhook.

## Included

- Telegram Mini App `initData` HMAC verification and freshness check.
- One entry per Telegram account (database uniqueness constraint).
- PostgreSQL persistence and parameterized SQL.
- Rate-limited entry endpoint.
- Telegram webhook secret verification.
- `/start`, `/help`, and `/rules` bot commands with an Open Mini App button.
- Admin-only, paginated entries endpoint.
- Optional AES-256-GCM encrypted email storage.
- Retention cleanup command.
- Sample frontend in `public/index.html`.

## Important launch requirements

This is application infrastructure, not proof that a giveaway is lawful, funded, audited, or endorsed by Telegram. Before accepting entries, publish clear official rules: sponsor identity, eligibility and restricted locations, entry period, prize amount and source, winner selection method, winner notification, claim deadline, taxes/fees, and privacy/retention policy. Do not claim a prize is guaranteed unless it is funded and available.

The sample UI and API do not request seed phrases, private keys, wallet signatures, or transfers. Do not add those features.

## 1. Create a Telegram bot

1. Open `@BotFather` in Telegram.
2. Run `/newbot` and follow the prompts.
3. Copy the bot token into `BOT_TOKEN`.
4. Configure the Mini App URL in BotFather after deploying the frontend.

Never put the bot token in frontend JavaScript or a public repository.

## 2. Configure environment variables

Copy `.env.example` to `.env` and fill in all required values.

Generate secrets:

```bash
openssl rand -hex 32
openssl rand -base64 32
```

Use a long random value for `ADMIN_API_KEY`, a URL-safe value for `TELEGRAM_WEBHOOK_SECRET`, and a base64-encoded 32-byte key for `DATA_ENCRYPTION_KEY`.

Keep the encryption key backed up securely. If it is lost, encrypted email addresses cannot be recovered. Do not rotate it without a migration plan.

`APP_ORIGIN` is the exact HTTPS origin serving the Mini App, for example `https://giveaway.example.com` (no trailing slash).
`WEBAPP_URL` is the full HTTPS URL of the Mini App.
`PUBLIC_API_URL` is the public base URL of this backend, for example `https://api-giveaway.example.com`.

For local development, use a PostgreSQL database and a public HTTPS tunnel if you need Telegram webhooks.

## 3. Install and run locally

```bash
npm install
cp .env.example .env
npm start
```

The API creates its table on startup and serves the included Mini App from the same origin. Test:

```bash
curl https://YOUR_API_HOST/healthz
```

The included `public/index.html` is served by the API from the same origin. Set `APP_ORIGIN` and `WEBAPP_URL` to the deployed service URL. The sample frontend calls `/api/...` directly.

## 4. Deploy

### Render

1. Push this folder to a private Git repository.
2. Create a new Render Blueprint and select the repository.
3. Render reads `render.yaml` and provisions the web service and PostgreSQL database.
4. Add the secret environment variables in the Render dashboard.
5. Set `PUBLIC_API_URL` to the deployed API base URL.
6. Set `APP_ORIGIN` and `WEBAPP_URL` to the deployed HTTPS frontend URL.
7. Deploy and check `/healthz`.

The included Render blueprint deploys the API, Mini App frontend, and database together on one origin.

## 5. Register the Telegram webhook

After deployment and after setting `PUBLIC_API_URL`, run:

```bash
npm run register-webhook
```

This calls Telegram `setWebhook` and configures the bot menu button. The webhook endpoint is:

`POST /telegram/webhook`

Telegram sends the configured secret in `X-Telegram-Bot-Api-Secret-Token`.

## 6. Configure the Mini App

In BotFather, set the Mini App URL to `WEBAPP_URL`. Start the bot and use `/start`. The bot replies with an Open Giveaway button. The bot menu button is also configured by the registration script.

## API

### `GET /healthz`
Database health check.

### `GET /api/config`
Public giveaway display configuration.

### `POST /api/entries`
Requires:
- `X-Telegram-Init-Data: <Telegram.WebApp.initData>`
- JSON body: `{"walletAddress": "0x...", "email": "optional@example.com", "termsAccepted": true}`

Wallet and email are optional. Telegram identity is taken only from the verified Telegram `initData`, never from a client-supplied user ID. Duplicate Telegram accounts receive HTTP `409`.

### `GET /api/admin/entries?limit=50&offset=0`
Requires `Authorization: Bearer YOUR_ADMIN_API_KEY`. Treat this endpoint and its output as confidential personal data. Use only over HTTPS; do not expose the key in browser code.

## Data retention

Set `RETENTION_END_AT` to the end of the promised retention period. After that date, run:

```bash
npm run cleanup
```

This deletes all giveaway entries. Schedule this command with your hosting provider or run it manually after the retention deadline. Also define backup expiration with your database provider; deleting live rows does not automatically erase database backups.

## Security checklist before launch

- [ ] HTTPS enabled for both frontend and API.
- [ ] Bot token, admin key, webhook secret, and encryption key stored as host secrets.
- [ ] PostgreSQL is not publicly exposed; use provider network controls.
- [ ] `APP_ORIGIN` and `WEBAPP_URL` are set to the deployed service origin/URL.
- [ ] Public rules, privacy notice, eligibility and retention dates are published.
- [ ] Test duplicate entry, invalid Telegram signature, stale initData, and unauthorized admin access.
- [ ] Restrict access to admin endpoint and rotate secrets if exposed.
- [ ] Configure database backups and backup deletion/retention.
- [ ] Do not collect more personal information than necessary.

## Notes

- The example assumes Node.js 20+. The backend stores the accepted terms version and acceptance timestamp, and rejects new entries after `GIVEAWAY_END_AT`.
- The default database SSL setting is enabled for hosted PostgreSQL. For a local database only, set `DATABASE_SSL=disable`.
- Telegram `initData` is time-limited; users should reopen the Mini App if their session expires.
- The sample frontend uses same-origin API paths. For separate frontend/API hosting, update the API base URL in `public/index.html` and configure CORS.
- No random winner selection or prize payout is implemented. Those require separately documented, auditable rules and a secure process.
