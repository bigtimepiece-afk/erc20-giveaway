const required = [
  "BOT_TOKEN",
  "DATABASE_URL",
  "APP_ORIGIN",
  "WEBAPP_URL",
  "ADMIN_API_KEY",
  "TELEGRAM_WEBHOOK_SECRET"
];

for (const name of required) {
  if (!process.env[name]) {
    throw new Error(`Missing required environment variable: ${name}`);
  }
}

function decodeEncryptionKey() {
  if (!process.env.DATA_ENCRYPTION_KEY) return null;
  const key = Buffer.from(process.env.DATA_ENCRYPTION_KEY, "base64");
  if (key.length !== 32) {
    throw new Error("DATA_ENCRYPTION_KEY must be base64 for exactly 32 bytes.");
  }
  return key;
}

module.exports = {
  botToken: process.env.BOT_TOKEN,
  databaseUrl: process.env.DATABASE_URL,
  appOrigin: process.env.APP_ORIGIN.replace(/\/$/, ""),
  webappUrl: process.env.WEBAPP_URL,
  adminApiKey: process.env.ADMIN_API_KEY,
  webhookSecret: process.env.TELEGRAM_WEBHOOK_SECRET,
  encryptionKey: decodeEncryptionKey(),
  port: Number(process.env.PORT || 3000),
  trustProxy: process.env.TRUST_PROXY === "1",
  initDataMaxAge: Number(process.env.TELEGRAM_INITDATA_MAX_AGE_SECONDS || 86400),
  giveawayTitle: process.env.GIVEAWAY_TITLE || "Giveaway",
  giveawayEndAt: process.env.GIVEAWAY_END_AT || null,
  retentionEndAt: process.env.RETENTION_END_AT || null,
  networkName: process.env.NETWORK_NAME || "BNB Smart Chain",
  chainId: Number(process.env.CHAIN_ID || 56),
  tokenSymbol: process.env.TOKEN_SYMBOL || "BNB",
  tokenContractAddress: process.env.TOKEN_CONTRACT_ADDRESS || null,
  termsVersion: process.env.TERMS_VERSION || "1"
};
