const config = require("./config");

async function telegram(method, payload) {
  const response = await fetch(
    `https://api.telegram.org/bot${config.botToken}/${method}`,
    {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload)
    }
  );
  const data = await response.json();
  if (!response.ok || !data.ok) {
    throw new Error(`Telegram API ${method} failed: ${data.description || response.status}`);
  }
  return data.result;
}

async function sendWelcome(chatId) {
  return telegram("sendMessage", {
    chat_id: chatId,
    text:
      `Welcome to ${config.giveawayTitle}.\\n\\n` +
      "Open the Mini App to review the rules and submit one entry. " +
      "Never share your wallet recovery phrase or private key.",
    reply_markup: {
      inline_keyboard: [[
        { text: "Open Giveaway", web_app: { url: config.webappUrl } }
      ]]
    }
  });
}

async function handleUpdate(update) {
  const message = update && update.message;
  if (!message || !message.chat || typeof message.text !== "string") return;

  const command = message.text.trim().split(/\s+/)[0].split("@")[0].toLowerCase();
  if (command === "/start" || command === "/help") {
    await sendWelcome(message.chat.id);
  } else if (command === "/rules") {
    await telegram("sendMessage", {
      chat_id: message.chat.id,
      text:
        "Please read the full giveaway rules and eligibility requirements " +
        "inside the Mini App before entering.",
      reply_markup: {
        inline_keyboard: [[
          { text: "Read Rules / Enter", web_app: { url: config.webappUrl } }
        ]]
      }
    });
  }
}

module.exports = { handleUpdate, telegram };
