const crypto = require("crypto");
const config = require("./config");

function safeEqual(a, b) {
  const left = Buffer.from(String(a));
  const right = Buffer.from(String(b));
  return left.length === right.length && crypto.timingSafeEqual(left, right);
}

function verifyTelegramInitData(initData) {
  if (typeof initData !== "string" || !initData || initData.length > 8192) {
    return { ok: false, reason: "Missing or invalid Telegram initData." };
  }

  const params = new URLSearchParams(initData);
  const receivedHash = params.get("hash");
  if (!receivedHash || !/^[a-f0-9]{64}$/i.test(receivedHash)) {
    return { ok: false, reason: "Missing Telegram signature." };
  }

  params.delete("hash");
  const dataCheckString = [...params.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([key, value]) => `${key}=${value}`)
    .join("\n");

  const secretKey = crypto
    .createHmac("sha256", "WebAppData")
    .update(config.botToken)
    .digest();

  const calculatedHash = crypto
    .createHmac("sha256", secretKey)
    .update(dataCheckString)
    .digest("hex");

  if (!safeEqual(calculatedHash, receivedHash.toLowerCase())) {
    return { ok: false, reason: "Telegram signature verification failed." };
  }

  const authDate = Number(params.get("auth_date"));
  const now = Math.floor(Date.now() / 1000);
  if (!Number.isFinite(authDate) || authDate > now + 60 ||
      now - authDate > config.initDataMaxAge) {
    return { ok: false, reason: "Telegram session expired. Reopen the Mini App." };
  }

  let user;
  try {
    user = JSON.parse(params.get("user") || "null");
  } catch {
    return { ok: false, reason: "Invalid Telegram user data." };
  }

  if (!user || !Number.isSafeInteger(Number(user.id)) || Number(user.id) <= 0) {
    return { ok: false, reason: "Telegram user identity is missing." };
  }

  return {
    ok: true,
    user: {
      id: String(user.id),
      username: typeof user.username === "string" ? user.username.slice(0, 64) : null,
      firstName: typeof user.first_name === "string" ? user.first_name.slice(0, 64) : null
    }
  };
}

function encryptEmail(email) {
  if (!email) return null;
  if (!config.encryptionKey) {
    throw new Error("Email collection is disabled until DATA_ENCRYPTION_KEY is configured.");
  }
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", config.encryptionKey, iv);
  const ciphertext = Buffer.concat([
    cipher.update(email, "utf8"),
    cipher.final()
  ]);
  return {
    ciphertext: ciphertext.toString("base64"),
    iv: iv.toString("base64"),
    authTag: cipher.getAuthTag().toString("base64")
  };
}

function decryptEmail(row) {
  if (!row.email_ciphertext) return null;
  if (!config.encryptionKey) return "[encryption key not configured]";
  const decipher = crypto.createDecipheriv(
    "aes-256-gcm",
    config.encryptionKey,
    Buffer.from(row.email_iv, "base64")
  );
  decipher.setAuthTag(Buffer.from(row.email_auth_tag, "base64"));
  return Buffer.concat([
    decipher.update(Buffer.from(row.email_ciphertext, "base64")),
    decipher.final()
  ]).toString("utf8");
}

module.exports = { verifyTelegramInitData, encryptEmail, decryptEmail, safeEqual };
