require("dotenv").config();

const express = require("express");
const path = require("path");
const helmet = require("helmet");
const cors = require("cors");
const { rateLimit } = require("express-rate-limit");
const config = require("./config");
const { pool, initializeDatabase } = require("./db");
const { telegramUser, adminOnly, telegramWebhookOnly } = require("./auth");
const { encryptEmail, decryptEmail } = require("./crypto");
const { handleUpdate } = require("./telegram");

const app = express();

if (config.trustProxy) app.set("trust proxy", 1);

app.disable("x-powered-by");
app.use(helmet({
  crossOriginResourcePolicy: { policy: "cross-origin" },
  contentSecurityPolicy: false
}));
app.use(cors({
  origin(origin, callback) {
    if (!origin || origin === config.appOrigin) return callback(null, true);
    return callback(new Error("Origin not allowed by CORS."));
  },
  methods: ["GET", "POST"],
  allowedHeaders: ["Content-Type", "X-Telegram-Init-Data", "Authorization"],
  maxAge: 600
}));
app.use(express.json({ limit: "16kb" }));

const entryLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 8,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Too many requests. Please try again later." }
});

app.get("/healthz", async (_req, res) => {
  try {
    await pool.query("SELECT 1");
    res.json({ ok: true, database: "connected" });
  } catch {
    res.status(503).json({ ok: false, database: "unavailable" });
  }
});

app.get("/api/config", (_req, res) => {
  res.set("Cache-Control", "no-store");
  res.json({
    title: config.giveawayTitle,
    networkName: config.networkName,
    chainId: config.chainId,
    tokenSymbol: config.tokenSymbol,
    tokenContractAddress: config.tokenContractAddress,
    giveawayEndAt: config.giveawayEndAt
  });
});

app.post("/api/entries", entryLimiter, telegramUser, async (req, res) => {
  try {
    const { walletAddress, email, termsAccepted } = req.body || {};

    if (config.giveawayEndAt) {
      const endAt = new Date(config.giveawayEndAt);
      if (Number.isNaN(endAt.getTime())) {
        return res.status(503).json({ error: "Giveaway end date is not configured correctly." });
      }
      if (Date.now() > endAt.getTime()) {
        return res.status(410).json({ error: "This giveaway has ended." });
      }
    }

    if (termsAccepted !== true) {
      return res.status(400).json({ error: "You must accept the giveaway rules." });
    }

    let wallet = null;
    if (walletAddress !== undefined && walletAddress !== null && walletAddress !== "") {
      if (typeof walletAddress !== "string" ||
          !/^0x[a-fA-F0-9]{40}$/.test(walletAddress)) {
        return res.status(400).json({ error: "Enter a valid EVM public wallet address." });
      }
      wallet = walletAddress;
    }

    let encrypted = null;
    if (email !== undefined && email !== null && email !== "") {
      if (typeof email !== "string" || email.length > 254 ||
          !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        return res.status(400).json({ error: "Enter a valid email address." });
      }
      encrypted = encryptEmail(email.trim().toLowerCase());
    }

    const result = await pool.query(
      `INSERT INTO giveaway_entries
        (telegram_user_id, telegram_username, wallet_address,
         email_ciphertext, email_iv, email_auth_tag, terms_version, terms_accepted_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())
       ON CONFLICT (telegram_user_id) DO NOTHING
       RETURNING id, created_at`,
      [
        req.telegramUser.id,
        req.telegramUser.username,
        wallet,
        encrypted?.ciphertext || null,
        encrypted?.iv || null,
        encrypted?.authTag || null,
        config.termsVersion
      ]
    );

    if (result.rowCount === 0) {
      return res.status(409).json({
        ok: false,
        code: "ALREADY_REGISTERED",
        message: "An entry already exists for this Telegram account."
      });
    }

    return res.status(201).json({
      ok: true,
      message: "Your entry has been recorded.",
      entryId: String(result.rows[0].id),
      createdAt: result.rows[0].created_at
    });
  } catch (error) {
    console.error("Entry submission failed:", error.message);
    return res.status(500).json({ error: "Unable to record entry. Please try again." });
  }
});

app.get("/api/admin/entries", adminOnly, async (req, res) => {
  try {
    const limit = Math.min(Math.max(Number(req.query.limit) || 50, 1), 200);
    const offset = Math.max(Number(req.query.offset) || 0, 0);
    const result = await pool.query(
      `SELECT id, telegram_user_id, telegram_username, wallet_address,
              email_ciphertext, email_iv, email_auth_tag, terms_version, terms_accepted_at, created_at
       FROM giveaway_entries
       ORDER BY created_at DESC
       LIMIT $1 OFFSET $2`,
      [limit, offset]
    );

    const entries = result.rows.map((row) => ({
      id: String(row.id),
      telegramUserId: String(row.telegram_user_id),
      telegramUsername: row.telegram_username,
      walletAddress: row.wallet_address,
      email: decryptEmail(row),
      termsVersion: row.terms_version,
      termsAcceptedAt: row.terms_accepted_at,
      createdAt: row.created_at
    }));

    const count = await pool.query("SELECT COUNT(*)::text AS total FROM giveaway_entries");
    res.set("Cache-Control", "no-store");
    res.json({ total: count.rows[0].total, limit, offset, entries });
  } catch (error) {
    console.error("Admin entries query failed:", error.message);
    res.status(500).json({ error: "Unable to retrieve entries." });
  }
});

app.post("/telegram/webhook", telegramWebhookOnly, async (req, res) => {
  // Acknowledge quickly; do not expose bot token or internal errors.
  res.sendStatus(200);
  try {
    await handleUpdate(req.body);
  } catch (error) {
    console.error("Telegram update handling failed:", error.message);
  }
});

// Serve the Mini App from the same origin as the API.
app.use(express.static(path.join(__dirname, "..", "public"), {
  index: "index.html",
  maxAge: "1h"
}));

app.use((err, _req, res, _next) => {
  if (err.message && err.message.includes("CORS")) {
    return res.status(403).json({ error: "Origin not allowed." });
  }
  console.error("Unhandled request error:", err.message);
  res.status(500).json({ error: "Internal server error." });
});

const server = app.listen(config.port, async () => {
  try {
    await initializeDatabase();
    console.log(`API listening on port ${config.port}`);
  } catch (error) {
    console.error("Database initialization failed:", error.message);
    server.close(() => process.exit(1));
  }
});

process.on("SIGTERM", () => server.close(() => pool.end()));
process.on("SIGINT", () => server.close(() => pool.end()));
