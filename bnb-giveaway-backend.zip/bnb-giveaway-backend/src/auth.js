const config = require("./config");
const { verifyTelegramInitData, safeEqual } = require("./crypto");

function telegramUser(req, res, next) {
  const initData = req.get("X-Telegram-Init-Data");
  const result = verifyTelegramInitData(initData);
  if (!result.ok) {
    return res.status(401).json({ error: result.reason });
  }
  req.telegramUser = result.user;
  next();
}

function adminOnly(req, res, next) {
  const authorization = req.get("Authorization") || "";
  const token = authorization.startsWith("Bearer ")
    ? authorization.slice(7)
    : "";
  if (!token || !safeEqual(token, config.adminApiKey)) {
    return res.status(401).json({ error: "Unauthorized." });
  }
  next();
}

function telegramWebhookOnly(req, res, next) {
  const supplied = req.get("X-Telegram-Bot-Api-Secret-Token") || "";
  if (!safeEqual(supplied, config.webhookSecret)) {
    return res.status(401).send("Unauthorized");
  }
  next();
}

module.exports = { telegramUser, adminOnly, telegramWebhookOnly };
