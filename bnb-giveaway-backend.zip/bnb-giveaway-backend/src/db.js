const { Pool } = require("pg");
const config = require("./config");

const pool = new Pool({
  connectionString: config.databaseUrl,
  ssl: process.env.DATABASE_SSL === "disable" ? false : { rejectUnauthorized: false },
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000
});

pool.on("error", (err) => {
  console.error("Unexpected PostgreSQL pool error:", err.message);
});

async function initializeDatabase() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS giveaway_entries (
      id BIGSERIAL PRIMARY KEY,
      telegram_user_id BIGINT NOT NULL UNIQUE,
      telegram_username TEXT,
      wallet_address VARCHAR(42),
      email_ciphertext TEXT,
      email_iv TEXT,
      email_auth_tag TEXT,
      terms_version TEXT NOT NULL DEFAULT '1',
      terms_accepted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE INDEX IF NOT EXISTS giveaway_entries_created_at_idx
      ON giveaway_entries (created_at DESC);
  `);
  await pool.query("ALTER TABLE giveaway_entries ADD COLUMN IF NOT EXISTS terms_version TEXT NOT NULL DEFAULT '1'");
  await pool.query("ALTER TABLE giveaway_entries ADD COLUMN IF NOT EXISTS terms_accepted_at TIMESTAMPTZ NOT NULL DEFAULT NOW()");
}

module.exports = { pool, initializeDatabase };
