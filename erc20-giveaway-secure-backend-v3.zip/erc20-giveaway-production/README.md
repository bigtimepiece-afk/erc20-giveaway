# ERC20 Giveaway Telegram Mini App — backend starter

## Configured organizer details
- Prize statement: 100,000 ERC20 tokens (not yet sufficiently identified)
- Opens: 2026-11-18 00:00 UTC (provisional)
- Closes: 2027-03-31 23:59 UTC (provisional)
- Selection: random draw (audit protocol must be published)
- Eligibility: worldwide where legally permitted (requires jurisdiction/age exclusions review)

## Before launch — mandatory verification
1. Confirm organizer legal identity and contact details.
2. Identify token name, ticker, chain/network, contract address, decimals and verify contract on the chain explorer.
3. Confirm whether 100,000 is the total pool or amount per winner; confirm winner count and allocation.
4. Verify the prize is funded/available and specify delivery timing and fees. Do not claim escrow/funding unless evidenced.
5. Have counsel review promotion, lottery/sweepstakes, sanctions, age, privacy, tax and advertising rules for each permitted jurisdiction. "Worldwide" is not a sufficient legal eligibility definition.
6. Finalize privacy notice and retention policy.
7. Set campaign dates/timezone and publish final terms before opening.
8. Generate DRAW_SEED securely, calculate SHA-256 commitment and publish commitment before registration starts. Keep seed secret until after closing/draw.
9. Configure the bot, database and admin secret in hosting environment variables.

## Security model
- Telegram Mini App `initData` HMAC verification on the server using BOT_TOKEN.
- Rejects stale signed sessions (24-hour maximum).
- Stores only Telegram user ID, accepted terms version and timestamp.
- Unique database constraint enforces one entry per Telegram account.
- Registration endpoint rate-limited; Helmet security headers enabled.
- Admin endpoints require a long random ADMIN_API_KEY.
- Draw is blocked until campaign is closed and DRAW_SEED is configured.
- Draw record is unique per campaign and stores seed reveal, commitment, participant-list hash and algorithm.

Important: this is a production-oriented starter, not a completed legal/compliance review or independently audited system. The current draw implementation supports one winner only. Set CAMPAIGN_WINNER_COUNT=1 until multi-winner support is implemented. Do not deploy with placeholder secrets or open registration until all launch checks are complete.

## Local run
1. Install Node.js 20+ and PostgreSQL.
2. Copy `.env.example` to `.env`; fill all secrets using a secure secret manager.
3. `npm install`
4. Create a PostgreSQL database and set DATABASE_URL.
5. `npm start`
6. Open http://localhost:3000 (registration only works in Telegram with a valid signed initData).

## Deployment
Deploy as a Node.js service on a host that supports persistent server processes and PostgreSQL. Set environment variables in the host dashboard. Configure Telegram Mini App URL to the HTTPS public URL. Do not expose BOT_TOKEN or ADMIN_API_KEY to the browser.


## Latest organizer-supplied campaign details (not independently verified)
- Organizer name supplied: CyberCoinvvs
- Contract address supplied: `0x854A21266A02cd2f4c31D3FB6f8A2271CF9DE8d8`
- Prize amount supplied: 100,000 ERC20 tokens
- Winner count: 1 (organizer-confirmed)
- Funding: organizer reports verified; obtain independent evidence before public claim
- Legal review: organizer reports approved; retain counsel's written scope/opinion
- Intended eligibility: worldwide where legally permitted; do not interpret as literally unrestricted

## Still required before public launch
- Exact blockchain/network (e.g. Ethereum mainnet or another EVM chain), token name and symbol.
- Verify the contract address on the correct chain; verify token decimals, ownership/issuer, transferability, supply and any transfer restrictions.
- Confirm that 100,000 tokens is the single winner's prize and the exact token delivery method.
- Organizer's verified legal entity name/address and public contact details.
- Privacy contact email, actual hosting/subprocessor list, international transfer mechanism, retention periods and lawful bases.
- Minimum participant age and prohibited jurisdictions; "worldwide" remains subject to local law, sanctions and eligibility restrictions.
- Publish final rules, privacy notice and SHA-256 commitment to the draw seed before opening registration.

`public/privacy.html` is a composed privacy-notice draft with required placeholders. It must be completed and reviewed by the Organizer's privacy/legal adviser before publication.


## Latest organizer-supplied configuration (16 November 2026)
- Network: BNB Smart Chain
- Contract address: `0x854A21266A02cd2f4c31D3FB6f8A2271CF9DE8d8`
- Token ticker supplied: `BNB` (must be checked against the contract's on-chain symbol)
- Prize pool supplied: 100,000 token units; one winner
- Privacy contact supplied: `erc20giveaway@gmail.com`
- Retention instruction: retain entry data until the giveaway ends (31 March 2027), then delete or anonymize when no longer needed, subject to legal obligations and dispute holds.

These are organizer-provided values, not independent verification. Before launch, verify the contract on BNB Smart Chain using a trusted chain explorer and confirm token name, symbol, decimals, transferability and prize balance. The privacy notice remains a draft: complete the legal controller identity/address, processors, international transfer details, lawful bases, age eligibility, and a concrete post-campaign deletion schedule. "Until the end" alone does not define how long records may be retained after the campaign for disputes or legal requirements.
