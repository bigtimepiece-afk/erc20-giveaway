import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import pg from "pg";
import crypto from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const { Pool } = pg;

const required = ["BOT_TOKEN", "DATABASE_URL", "ADMIN_API_KEY"];
for (const name of required) {
  if (!process.env[name]) {
    console.error(`Missing required environment variable: ${name}`);
    process.exit(1);
  }
}
if (process.env.ADMIN_API_KEY.length < 32) {
  console.error("ADMIN_API_KEY must be at least 32 characters.");
  process.exit(1);
}

const config = {
  start: new Date(process.env.CAMPAIGN_START || "2026-11-18T00:00:00Z"),
  end: new Date(process.env.CAMPAIGN_END || "2027-03-31T23:59:59Z"),
  timezone: process.env.CAMPAIGN_TIMEZONE || "UTC",
  prize: process.env.CAMPAIGN_PRIZE_DESCRIPTION || "Prize details pending verification",
  winnerCount: Number.parseInt(process.env.CAMPAIGN_WINNER_COUNT || "1", 10),
  termsVersion: process.env.TERMS_VERSION || "1.0-draft",
  drawSeed: process.env.DRAW_SEED || "",
  launchApproved: process.env.CAMPAIGN_LAUNCH_APPROVED === "true"
};
if (!Number.isFinite(config.start.getTime()) || !Number.isFinite(config.end.getTime()) ||
    config.end <= config.start || !Number.isInteger(config.winnerCount) || config.winnerCount < 1) {
  console.error("Invalid campaign date or winner-count configuration.");
  process.exit(1);
}
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: true } : false
});

app.disable("x-powered-by");
app.set("trust proxy", 1);
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "https://telegram.org"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:"],
      connectSrc: ["'self'"],
      frameAncestors: ["https://web.telegram.org", "https://*.telegram.org"]
    }
  },
  crossOriginEmbedderPolicy: false
}));
app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public"), { extensions: ["html"] }));

const registerLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 8,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Too many attempts. Please try again later." }
});
const adminLimiter = rateLimit({ windowMs: 60 * 1000, limit: 20, standardHeaders: "draft-7", legacyHeaders: false });

function safeEqualHex(a, b) {
  if (!/^[a-f0-9]{64}$/i.test(a || "") || !/^[a-f0-9]{64}$/i.test(b || "")) return false;
  return crypto.timingSafeEqual(Buffer.from(a, "hex"), Buffer.from(b, "hex"));
}

function verifyTelegramInitData(initData) {
  if (typeof initData !== "string" || initData.length > 10_000) throw new Error("Missing or invalid Telegram session.");
  const params = new URLSearchParams(initData);
  const suppliedHash = params.get("hash");
  if (!suppliedHash) throw new Error("Invalid Telegram signature.");

  const entries = [];
  for (const [key, value] of params.entries()) {
    if (key !== "hash" && key !== "signature") entries.push([key, value]);
  }
  entries.sort(([a], [b]) => a.localeCompare(b));
  const dataCheckString = entries.map(([k, v]) => `${k}=${v}`).join("\n");

  const secretKey = crypto.createHmac("sha256", "WebAppData")
    .update(process.env.BOT_TOKEN)
    .digest();
  const calculatedHash = crypto.createHmac("sha256", secretKey)
    .update(dataCheckString)
    .digest("hex");

  if (!safeEqualHex(suppliedHash, calculatedHash)) throw new Error("Telegram session signature could not be verified.");

  const authDate = Number(params.get("auth_date"));
  const now = Math.floor(Date.now() / 1000);
  if (!Number.isInteger(authDate) || authDate > now + 30 || now - authDate > 60 * 60 * 24) {
    throw new Error("Telegram session expired. Reopen the Mini App from Telegram.");
  }

  let user;
  try { user = JSON.parse(params.get("user") || ""); } catch { throw new Error("Telegram user information is invalid."); }
  if (!user || (typeof user.id !== "number" && typeof user.id !== "string")) {
    throw new Error("Telegram account could not be identified.");
  }
  return { telegramUserId: String(user.id) };
}

function requireAdmin(req, res, next) {
  const provided = (req.get("authorization") || "").replace(/^Bearer\s+/i, "");
  const expected = process.env.ADMIN_API_KEY;
  const a = Buffer.from(provided);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return res.status(401).json({ error: "Unauthorized." });
  }
  next();
}

function campaignTimeStatus(now = new Date()) {
  if (now < config.start) return "scheduled";
  if (now <= config.end) return "open";
  return "closed";
}
function campaignStatus(now = new Date()) {
  const timeStatus = campaignTimeStatus(now);
  if (timeStatus === "open" && !config.launchApproved) return "pending_approval";
  return timeStatus;
}
function registrationIsEnabled(now = new Date()) {
  return config.launchApproved && Boolean(config.drawSeed) && !config.drawSeed.startsWith("replace_") && !config.termsVersion.includes("draft") && campaignTimeStatus(now) === "open";
}

app.get("/api/config", async (_req, res) => {
  const result = await pool.query("SELECT COUNT(*)::int AS count FROM giveaway_entries");
  const commitment = config.drawSeed
    ? crypto.createHash("sha256").update(config.drawSeed).digest("hex")
    : null;
  res.json({
    campaign: {
      status: campaignStatus(),
      start: config.start.toISOString(),
      end: config.end.toISOString(),
      timezone: config.timezone,
      prize: config.prize,
      winnerCount: config.winnerCount,
      termsVersion: config.termsVersion,
      entries: result.rows[0].count,
      drawCommitment: commitment,
      drawProtocolReady: Boolean(config.drawSeed) && !config.drawSeed.startsWith("replace_"),
      launchApproved: config.launchApproved,
      registrationEnabled: registrationIsEnabled()
    }
  });
});

app.post("/api/register", registerLimiter, async (req, res) => {
  try {
    const { telegramUserId } = verifyTelegramInitData(req.body?.initData);
    if (!registrationIsEnabled()) {
      const status = campaignTimeStatus();
      const message = !config.launchApproved || !config.drawSeed || config.drawSeed.startsWith("replace_") || config.termsVersion.includes("draft")
        ? "Registration is not activated. The organizer must complete verification and approve launch."
        : status === "scheduled" ? "Registration has not opened yet." : "Registration is closed.";
      return res.status(409).json({ error: message });
    }
    if (req.body?.acceptTerms !== true || req.body?.termsVersion !== config.termsVersion) {
      return res.status(400).json({ error: "Please accept the current giveaway rules." });
    }

    const result = await pool.query(
      `INSERT INTO giveaway_entries (telegram_user_id, accepted_terms_version)
       VALUES ($1, $2)
       ON CONFLICT (telegram_user_id) DO NOTHING
       RETURNING id, accepted_at`,
      [telegramUserId, config.termsVersion]
    );
    if (result.rowCount === 0) {
      return res.status(409).json({ error: "This Telegram account already has an entry." });
    }
    res.status(201).json({ success: true, message: "Your entry has been recorded.", entryId: result.rows[0].id });
  } catch (error) {
    res.status(401).json({ error: error.message || "Registration could not be completed." });
  }
});

app.get("/api/rules", (_req, res) => {
  res.json({
    version: config.termsVersion,
    status: "DRAFT — organizer verification required",
    rules: [
      "No purchase or payment is required to enter.",
      "One entry per verified Telegram account.",
      "Entries are accepted only between the published opening and closing times (UTC).",
      "Eligibility is worldwide only where participation is lawful; restricted locations and age requirements must be finalized before launch.",
      "The prize is currently described as 100,000 ERC20 tokens. Token name, symbol, contract address, network, decimals, custody and distribution per winner are not yet verified.",
      "Winner selection is intended to be random. The organizer must publish the seed commitment before entries open and reveal the seed with the draw audit after closing.",
      "Winner notification, response deadline, identity checks if legally required, taxes, unclaimed-prize handling and delivery schedule must be finalized before launch.",
      "Never provide a seed phrase, private key, wallet password or payment to claim a prize."
    ]
  });
});

app.get("/api/admin/stats", adminLimiter, requireAdmin, async (_req, res) => {
  const result = await pool.query("SELECT COUNT(*)::int AS entries, MIN(accepted_at) AS first_entry, MAX(accepted_at) AS last_entry FROM giveaway_entries");
  res.json({ campaignStatus: campaignStatus(), ...result.rows[0] });
});

// A single immutable draw record is enforced by campaign_id UNIQUE.
// Seed commitment must be published before registration; reveal it with audit output.
app.post("/api/admin/draw", adminLimiter, requireAdmin, async (_req, res) => {
  if (campaignTimeStatus() !== "closed") return res.status(409).json({ error: "The campaign must be closed before drawing." });
  if (!config.launchApproved || config.termsVersion.includes("draft")) return res.status(409).json({ error: "The campaign was not approved for launch; do not run a draw." });
  if (!config.drawSeed || config.drawSeed.startsWith("replace_")) {
    return res.status(503).json({ error: "DRAW_SEED is not configured." });
  }
  const seedCommitment = crypto.createHash("sha256").update(config.drawSeed).digest("hex");
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    await client.query("LOCK TABLE giveaway_entries IN SHARE MODE");
    const existing = await client.query("SELECT * FROM giveaway_draws WHERE campaign_id = $1", ["erc20-giveaway-2026-2027"]);
    if (existing.rowCount) {
      await client.query("ROLLBACK");
      return res.status(409).json({ error: "A draw has already been recorded.", draw: existing.rows[0] });
    }
    const entries = await client.query("SELECT telegram_user_id FROM giveaway_entries ORDER BY telegram_user_id ASC");
    const ids = entries.rows.map(r => r.telegram_user_id);
    if (ids.length < config.winnerCount) {
      await client.query("ROLLBACK");
      return res.status(409).json({ error: "There are fewer eligible entries than configured winners." });
    }
    const participantList = ids.join("\n");
    const participantListHash = crypto.createHash("sha256").update(participantList).digest("hex");
    // Deterministic HMAC ranking: independently reproducible from the revealed seed and participant list.
    const ranked = ids.map(id => ({
      id,
      score: crypto.createHmac("sha256", config.drawSeed).update(`erc20-giveaway-2026-2027:${id}`).digest("hex")
    })).sort((a, b) => a.score.localeCompare(b.score));
    const winnerIds = ranked.slice(0, config.winnerCount).map(x => x.id);
    // Current schema stores one winner; enforce one until multi-winner schema is explicitly configured.
    if (winnerIds.length !== 1) {
      await client.query("ROLLBACK");
      return res.status(400).json({ error: "This starter currently supports one winner. Configure winner count as 1 or extend the draw schema." });
    }
    const inserted = await client.query(
      `INSERT INTO giveaway_draws
       (campaign_id, winner_telegram_user_id, eligible_entry_count, winner_count, seed_commitment, seed_reveal, participant_list_hash, algorithm)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      ["erc20-giveaway-2026-2027", winnerIds[0], ids.length, 1, seedCommitment, config.drawSeed, participantListHash, "HMAC-SHA256 ranking; ascending score; tie-break by Telegram user ID"]
    );
    await client.query("COMMIT");
    res.json({ success: true, draw: inserted.rows[0] });
  } catch (error) {
    await client.query("ROLLBACK");
    res.status(500).json({ error: "Draw failed. No winner was recorded." });
  } finally {
    client.release();
  }
});

app.get("/health", (_req, res) => res.json({ ok: true }));

async function start() {
  const schema = await fs.readFile(path.join(__dirname, "db/schema.sql"), "utf8");
  await pool.query(schema);
  const port = Number(process.env.PORT || 3000);
  app.listen(port, () => console.log(`ERC20 Giveaway app listening on ${port}`));
}
start().catch(err => { console.error("Startup failed:", err); process.exit(1); });
