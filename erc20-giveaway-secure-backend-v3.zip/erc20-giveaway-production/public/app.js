const tg = window.Telegram?.WebApp;
if (tg) { tg.ready(); tg.expand(); try { tg.setHeaderColor("#06133d"); tg.setBackgroundColor("#050d2b"); } catch {} }
const $ = id => document.getElementById(id);
let campaign;
async function loadConfig() {
  try {
    const r = await fetch("/api/config");
    const data = await r.json();
    campaign = data.campaign;
    $("entries").textContent = campaign.entries.toLocaleString();
    const statusText = campaign.status === "scheduled" ? "Registration opens November 18, 2026 (UTC)." :
      campaign.status === "open" ? "Registration is open." : "Registration is closed.";
    $("status").textContent = statusText;
    $("join").disabled = campaign.status !== "open" || !tg;
    if (!tg) $("message").textContent = "Open this page inside the Telegram Mini App to register.";
  } catch { $("status").textContent = "Campaign information is temporarily unavailable."; }
}
$("accept").addEventListener("change", () => { $("join").disabled = !campaign || campaign.status !== "open" || !tg || !$("accept").checked; });
$("join").addEventListener("click", async () => {
  $("join").disabled = true; $("message").textContent = "Verifying your Telegram session…";
  try {
    const response = await fetch("/api/register", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ initData: tg?.initData, acceptTerms: $("accept").checked, termsVersion: campaign.termsVersion })
    });
    const data = await response.json();
    $("message").textContent = data.message || data.error || "Registration could not be completed.";
    if (response.ok) { $("accept").checked = false; await loadConfig(); }
  } catch { $("message").textContent = "Network error. Please try again."; }
  finally { $("join").disabled = !campaign || campaign.status !== "open" || !$("accept").checked; }
});
loadConfig();