CREATE TABLE IF NOT EXISTS giveaway_entries (
  id BIGSERIAL PRIMARY KEY,
  telegram_user_id TEXT NOT NULL UNIQUE,
  accepted_terms_version TEXT NOT NULL,
  accepted_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS giveaway_draws (
  id BIGSERIAL PRIMARY KEY,
  campaign_id TEXT NOT NULL UNIQUE,
  drawn_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  winner_telegram_user_id TEXT NOT NULL,
  eligible_entry_count INTEGER NOT NULL,
  winner_count INTEGER NOT NULL,
  seed_commitment TEXT NOT NULL,
  seed_reveal TEXT NOT NULL,
  participant_list_hash TEXT NOT NULL,
  algorithm TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS giveaway_entries_accepted_at_idx
  ON giveaway_entries (accepted_at);
